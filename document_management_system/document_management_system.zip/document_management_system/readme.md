## Document  Managerment System

## Install and createsuperuser
    $python -m venv project-name
    $project-name\Scripts\activate.bat
    $ pip install -r requirements.txt
    $ pythn manage.py migrate
    $ python manage.py createsuperuser
    $ email: username@gmail.com
    $ username: username
    $ password: 0
    $ password confirmation: 0
    $ python manage.py runserver
    To activate manager account login with admin and activate menager

