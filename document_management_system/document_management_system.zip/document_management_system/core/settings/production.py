from .base import *

SECRET_KEY = config('SECRET_KEY')
ALLOWED_HOSTS = ['your-domian-name']


DEBUG = True