from django.test import TestCase
from documents.urls import Document

#class DocumentTestCase(TestCase):
    # def setUp(self):
    #     Document.objects.create(name="username")
    #     Document.objects.create(name=" email")

    # def test_Accounts(self):
        
    #     username = Document.objects.get(name="username")
    #     email = Document.objects.get(name=" email")
        
    #     self.assertEqual(username.insert(), 'username')
    #     self.assertEqual(email.insert(), 'email')